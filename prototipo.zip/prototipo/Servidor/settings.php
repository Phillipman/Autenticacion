<?php
error_reporting(0);

define("SOCKET_HOST", "127.0.0.1");
define("SOCKET_PORT", 65500);

define("HOST", "192.168.0.104");
define("USER", "root");
define("PASS", "");
define("DB", "autentificacion");

?>
